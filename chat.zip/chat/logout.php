<?php 

session_start();

$connect = mysqli_connect("localhost","root","","acechat");

if (isset($_SESSION['chatbot'])) {
	$email = $_SESSION['chatbot'];
	 mysqli_query($connect, "UPDATE signup SET status='Offline' WHERE email='$email'");
	 unset($_SESSION['chatbot']);

	 echo "<script>alert('You have successfully Logged out')</script>";
	 echo "<script>window.location.href='login.php'</script>";
}

 ?>