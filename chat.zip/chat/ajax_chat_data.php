<?php 

include("connection.php");

include("function.php");

$user = $_SESSION['chatbot'];
$reciever = $_SESSION['id'];
$c = $_SESSION['c'];

$query= "SELECT * FROM chat WHERE sender='$user' AND reciever='$reciever' OR reciever='$user' AND sender='$reciever' ORDER BY time_date DESC";

$result = mysqli_query($connect,$query);

if (mysqli_num_rows($result)==0) {
   $output = "<h3 class='text-center'>Start chatting with $c Now!!!</h3>";
  }else{
while ($row = mysqli_fetch_array($result)) {
	
    
    $username = $row['sender'];
    $recievers = $row['reciever'];
    $message = $row['message'];
    $time = $row['time_date'];
    $status = $row['status'];




$t = strtotime($time);

$time_ago = time_Ago($t); 




    if ($user==$username AND $reciever==$recievers) {
         
       $output = sender($recievers,$time_ago,$message,$status);
    }


    if ($reciever==$username AND $user==$recievers) {
       $output = reciever($username,$time_ago,$message);
    }
   

}

  }
echo $output;









 ?>