<?php 

include("connection.php");

include("function.php");

$reciever = $_SESSION['chatbot'];

  $n = "SELECT * FROM chat WHERE reciever='$reciever' AND status='unread'";

  $res = mysqli_query($connect,$n);


  $count = mysqli_num_rows($res);
  $_SESSION['noti_count']=$count;

  if (mysqli_num_rows($res)==0) {
  	 echo "<h3 class='text-center my-5'>No Notification </h3>";
  }

   
   while ($row = mysqli_fetch_array($res)) {
   	  
   	  $sender = $row['sender'];
   	  $reciever =$row['reciever'];
   	  $message = $row['message'];
   	  $time =$row['time_date'];
   	  $img = $row['profile'];

   	  notification($img,$message,$sender,$time);

   	  
   }



 ?>