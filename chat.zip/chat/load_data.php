<?php 

session_start();
 $connect = mysqli_connect("localhost","root","","acechat");





 $email = $_SESSION['chatbot'];


 $query = "SELECT * FROM signup WHERE email='$email'";

 $res = mysqli_query($connect,$query);

 $row = mysqli_fetch_array($res);


 if ($res) {
 	echo '<img src="img/'.$row['profile'].'" class="img-responsive card img-card my-3" style="width:270px;height:220px;" id="img">';
 }else{
 	echo "Failed";
 }





 ?>