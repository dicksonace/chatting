<?php 
include("connection.php");

$user = $_SESSION['chatbot'];
$reciever = $_SESSION['id'];

$img = $_SESSION['pp'];

$message = $_POST['message'];


$error = array();

if (empty($message)) {
	$error['m'] = "";
}



if (count($error)==0) {
$query = "INSERT INTO chat(sender,reciever,message,time_date,status,profile) VALUES('$user','$reciever','$message',NOW(),'unread','$img')";

$result =mysqli_query($connect,$query);

if ($result) {
	
}
}








 ?>