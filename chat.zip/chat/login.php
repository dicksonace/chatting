<?php 



include("header.php");

if (isset($_SESSION['chatbot'])) {
     header("refresh:1;url=index.php"); 
}


if (isset($_POST['login'])) {
	
	$email = $_POST['email'];
	$pass = $_POST['pass'];

	$errors = array();


	if (empty($email)) {
		$errors['l'] = "Email is empty";
	}else if(empty($pass)){
		$errors['l'] = "Password is empty";
	}



	if (count($errors)==0) {
		
		$query = "SELECT * FROM signup WHERE email='$email' AND password='$pass'";
		$result = mysqli_query($connect,$query);
   

		if (mysqli_num_rows($result) == 1) {  

			echo "<script>alert('You have successfully Login')</script>";
   
			  mysqli_query($connect, "UPDATE signup SET status='Online' WHERE email='$email'");
		
			
			$_SESSION['chatbot'] = $email;
			echo "<script>window.location.href='index.php'</script>";
			exit();
		}else{

			echo "<script>alert('Invalid Account')</script>";
            
		}
	}
}
 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body style="background-image: url(img/1.jpg);">
<br><br><br><br>
	<div class="container-fluid">
		<div class="col-md-12">
			<div class="row">
				<div class="col-md-3"></div>
				<div class="col-md-6 my-5 jumbotron" style="opacity: 0.9;">
					<?php
                        
                     if (isset($errors['l'])) {
                    	echo '<h4 class="alert alert-danger text-center">'.$errors['l'].'</h4>';
                        }else{
                        	
                        }


                        

                        


                        
					?>
					
					<h2 class="text-center">Login</h2>
					<form method="post" >
						<div class="form-group">
							<label>Email</label>
							<input type="text" name="email" class="form-control" autocomplete="off" value="<?php if(isset($_POST['email'])) echo $_POST['email']; ?>">
						</div>
						

						<div class="form-group">
							<label>Password</label>
							<input type="password" name="pass" class="form-control" autocomplete="off" autocomplete="off">
						</div>

						<input type="submit" name="login" class="btn btn-success" id="login" value="Login"><br>


						<span class="text-center mx-3">	Don't have an account? click <a href="signup.php">Here</a> </span>    <span> Forgotten Password? click <a href="forgetten_password.php">Here</a></span>
					</form>
				</div>
				<div class="col-md-3"></div>
			</div>
		</div>
	</div>


<br><br><br><br>
<?php 

include("footer.php");
 ?>
</body>
</html>