<?php

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
  <div class="bg-light border-right" id="sidebar-wrapper" >
    <div style="height: 14vh;border-bottom: 2px solid gray;">
      <div class="sidebar-heading text-center" style="width: 40vh;"><b>Users</b>
        <form method="post" style="position: fixed;" class="my-2 text-center mx-4" id="me">
        <input type="text" name="search" class="form-control shadow" id="search" placeholder="Search a user" autocomplete="off" maxlength="10">
       </form> </div>
      
    </div>
     <div style="z-index: 1;height: 67vh;overflow-x: hidden;overflow-y: scroll;">
      <div class="list-group list-group-flush" >
       

       <div style="height: auto;" >
       	<div id="done">
       <?php

       $email = $_SESSION['chatbot'];
        
        $query = "SELECT * FROM signup WHERE email !='$email'";

        $result = mysqli_query($connect,$query);


        while ($row = mysqli_fetch_array($result)) {
               
               if ($row['status'] == 'Online') {
                   
                   chatonline($row['id'],$row['profile'],$row['firstname'],$row['role']);
               }else{
                    chatoffline($row['id'],$row['profile'],$row['firstname'],$row['role']);
               }
        }
    


       ?>
        </div>
       </div>
      </div>
  </div>
</div>
</body>
</html>