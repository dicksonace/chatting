<?php 
session_start();
 $connect = mysqli_connect("localhost","root","","acechat");
 