<?php 
session_start();
 $connect = mysqli_connect("localhost","root","","acechat");

if (isset($_POST['update'])) {
	$file_extension = pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION);

   $allowed_image_extension = array(
        "png",
        "jpg",
        "jpeg"
    );

  $file = $_FILES['image'];


  $errrors = array();


  if (empty($_FILES['image'])) {
    $errrors['u'] = "Choose a profile";
  }else if (($_FILES["file-input"]["size"] > 2000000)) {
     $errrors['u'] = "Image size is too big";
  }else if (!in_array($file_extension, $allowed_image_extension)) {
    $errrors['u'] = "Only PNG and JPEG are allowed";
  }


  if (count($errrors)==0) {
    $email = $_SESSION['email'];


    $up = "UPDATE signup SET profile='".$_FILES['image']['name']."' WHERE email='$email'";
    $re = mysqli_query($connect,$up);
     

    if ($re) {
      move_uploaded_file($_FILES['image']['tmp_name'] , "img/".$_FILES['image']['name']."");
    }
  }
}


  
 ?>