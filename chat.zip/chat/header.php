<?php 


error_reporting(0);

include("connection.php");





$q = "SELECT * FROM signup WHERE email='".$_SESSION['chatbot']."'";

$qq = mysqli_query($connect,$q);

$row = mysqli_fetch_array($qq);

$_SESSION['pp'] =$row['profile'];



 ?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Hermex-Studio.Com</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/js/all.min.js">

  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,500,600,700,700i|Montserrat:300,400,500,600,700" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">
  <!--Jquery UI--->
  <link rel="stylesheet" type="text/css" href="ui/jquery-ui.css">
   <link rel="stylesheet" type="text/css" href="ui/jquery-ui.min.css">
    <link rel="stylesheet" type="text/css" href="ui/jquery-ui.structure.css">
    <link rel="stylesheet" type="text/css" href="ui/jquery-ui.structure.min.css">
    <link rel="stylesheet" type="text/css" href="ui/jquery-ui.theme.css">
    <link rel="stylesheet" type="text/css" href="ui/jquery-ui.them.min.css">

    <script type="text/javascript" src="ui/jquery-ui.js"></script>
     <script type="text/javascript" src="ui/jquery-ui.min.js"></script>
      <script type="text/javascript" src="ui/jquery-ui.js"></script>
  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<body>
  <header id="header" style="background-color: #F2F4F4 ;">

    <div id="topbar">
      <div class="container">
        <div class="social-links">
          <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
          <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
          <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
          <a href="#" class="instagram"><i class="fa fa-instagram"></i></a>
        </div>
      </div>
    </div>

    <div class="container">

      <div class="logo float-left">
        <!-- Uncomment below if you prefer to use an image logo -->
        <h1 class="text-light"><a href="index.php" class="scrollto"><span><b class="text-danger" style="margin-left: -70px;">Web App</b></span></a></h1>
        <!-- <a href="#header" class="scrollto"><img src="img/logo.png" alt="" class="img-fluid"></a> -->
      </div>

      <nav class="main-nav float-right d-none d-lg-block">
        <ul>
         <?php 

           if (isset($_SESSION['chatbot'])) {
           	 echo '
          <li class="active"><a href="index.php">Chat</a></li>
          <li><a href="#portfolio" id="noti">(<span class="text-danger">'.$_SESSION['noti_count'].'</span>)Notifications<span><i class="fa fa-bell fa-1x"></i></span></a></li>
          <li><a href="" class="account">My Account</a></li>
          <li class="account_set"><a href="#portfolio">Account Settings</a></li>
          <li><a href="logout.php">Logout</a></li> 
            <li><a href="#portfolio"><img src="img/'.$row['profile'].'" class="profile" style="width: 35px;height:35px;border-radius: 50px;margin-left: 10px;"></a></li>

           	 ';
           }else{
           	echo '
          <li><a href="login.php">Login</a></li>
          <li><a href="signup.php">Create Account</a></li>
           	 ';
           }

          ?>
        </ul>
      </nav>
   
    </div>
  </header>
 




  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/mobile-nav/mobile-nav.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/waypoints/waypoints.min.js"></script>
  <script src="lib/counterup/counterup.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/isotope/isotope.pkgd.min.js"></script>
  <script src="lib/lightbox/js/lightbox.min.js"></script>
  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>
</body>
</html>