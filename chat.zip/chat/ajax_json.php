<?php 

$data['fname'] = "Dickson";

echo json_encode($data);


 ?>