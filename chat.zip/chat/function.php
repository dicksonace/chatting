<?php 





function users_online($img,$fname,$role){
	$on = "
<div class='row'>
	<div class='col-md-3 '>

		<img src=img/$img style='width: 45px;border-radius: 50px;height:45px;' class='card img-card img-responsive' align='left'><br>
		<div style='border: 5px solid green;border-radius: 10px;width: 5px;position: absolute;margin-left: 70%;margin-top: 15%;'></div>

	</div>
	<div class='col-md-9 text-left'>
		<h6>$fname<br><p style='font-size: 9px;'>$role</p></h6>

	</div>

</div>
          <hr>
	";

	echo $on;
}




function chatonline($id,$img,$fname,$role){
	$chat = "
    <a href='index.php?id=$id'>
     <div class='row my-3 mx-2' id='$id' class='click' style='cursor:pointer;'>
     <div class='col-md-3 '>

    <img src=img/$img style='width: 45px;border-radius: 50px;height:45px;' class='card img-card img-responsive' align='left'><br>
    <div style='border: 5px solid green;border-radius: 10px;width: 5px;position: absolute;margin-left: 70%;margin-top: 15%;'></div>

  </div>
  <div class='col-md-9 text-left'>
    <h6>$fname<br><p style='font-size: 9px;'>$role</p></h6>

  </div>

</div>
          <hr>
    </a>


	";

	echo $chat;
}




function chatoffline($id,$img,$fname,$role){
	$chat = "
 <a href='index.php?id=$id'>
    <div class='row my-3 mx-2' id='$id' class='click' style='cursor:pointer;'>
     <div class='col-md-3 '>

    <img src=img/$img style='width: 45px;border-radius: 50px;height:45px;' class='card img-card img-responsive' align='left'><br>
  </div>
  <div class='col-md-9 text-left'>
    <h6>$fname<br><p style='font-size: 9px;'>$role</p></h6>

  </div>

</div>
          <hr>

</a>
	";

	echo $chat;
}



function sender($reciever,$time,$message,$status){
  $send = "
    <div class='' style='float:right;padding:10px;height:auto;width:500px;'>
      <p style=' word-break: break-all;padding:5px;color:white;max-wdth: 300px;border-radius:10px;' class='bg-info'>$time<br>
      $message <br><b style='float:right;'>$status</b></p>
    
    </div>";

    echo $send;
}


function reciever($sender,$time,$message){
   $r = "<div class='' style='float:left;padding:10px;height:auto;width:500px;'>
      <p style=' word-break: break-all;padding:5px;color:white;max-wdth: 300px;border-radius:10px;' class='bg-success'>$time<br>
      $message </p>
    </div>";

   echo $r;
}

function notification($img,$message,$sender,$date){
  $no = "
      <div class='container-fluid'>
        <div class='col-md-12'>
          <div class='row' >
            <div class='col-md-2'>
              <img src='img/$img' style='width: 55px;height:55px;border-radius: 50px;margin-left: 10px;'>
            </div>
            <div class='col-md-9'>
              <p>$message<br><b>From:$sender  <br>@$date</b></p>
            </div>
          </div>
        </div>
      </div>
      <hr>
  ";

  echo $no;
}



    
function time_Ago($time) { 

  
  $diff  = time() - $time; 
  
  // Time difference in seconds 
  $sec   = $diff; 
  
  // Convert time difference in minutes 
  $min   = round($diff / 60 ); 
  
  // Convert time difference in hours 
  $hrs   = round($diff / 3600); 
  
  // Convert time difference in days 
  $days  = round($diff / 86400 ); 
  
  // Convert time difference in weeks 
  $weeks   = round($diff / 604800); 
  
  // Convert time difference in months 
  $mnths   = round($diff / 2600640 ); 
  
  // Convert time difference in years 
  $yrs   = round($diff / 31207680 ); 
  
  // Check for seconds 
  if($sec <= 60) { 
    $m= "$sec seconds ago"; 
  } 
  
  // Check for minutes 
  else if($min <= 60) { 
    if($min==1) { 
      $m= "one minute ago"; 
    } 
    else { 
      $m= "$min minutes ago"; 
    } 
  } 
  
  // Check for hours 
  else if($hrs <= 24) { 
    if($hrs == 1) { 
      $m ="an hour ago"; 
    } 
    else { 
      $m ="$hrs hours ago"; 
    } 
  } 
  
  // Check for days 
  else if($days <= 7) { 
    if($days == 1) { 
      $m ="Yesterday"; 
    } 
    else { 
      $m ="$days days ago"; 
    } 
  } 
  
  // Check for weeks 
  else if($weeks <= 4.3) { 
    if($weeks == 1) { 
      $m ="a week ago"; 
    } 
    else { 
      $m ="$weeks weeks ago"; 
    } 
  } 
  
  // Check for months 
  else if($mnths <= 12) { 
    if($mnths == 1) { 
      $m = "a month ago"; 
    } 
    else { 
      $m = "$mnths months ago"; 
    } 
  } 
  
  // Check for years 
  else { 
    if($yrs == 1) { 
      $m = "one year ago"; 
    } 
    else { 
      $m = "$yrs years ago"; 
    } 
  } 

  return $m;

} 






 ?>