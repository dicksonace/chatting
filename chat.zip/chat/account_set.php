<?php 
include("connection.php");


$emails = $_SESSION['chatbot'];
$contacts = $_SESSION['contact'];


$fname = $_POST['fname'];
$sname = $_POST['sname'];
$country = $_POST['country'];
$contact = $_POST['contact'];


$errors = array();





         $c = "SELECT contact FROM signup WHERE contact='$contact' AND contact!='$contacts' ";
   $cc = mysqli_query($connect,$c);



      if (empty($fname)) {
      	 $errors['s'] = "First name is empty";
      }else if(empty($sname)){
      	$errors['s'] = "Surname is empty";
      }else if(empty($country)){
      	$errors['s'] = "Select Your Country";
      }else if(empty($contact)){
      	$errors['s'] = "Contact is empty";
      }else if(strlen($fname) < 4){
      	$errors['s'] = "First Name is too short";
      }else if(strlen($sname) < 4){
      	$errors['s'] = "Surname is too short";
      }else if(strlen($contact) < 10){
      	$errors['s'] = "Invalid Contact";
      }else if(!preg_match("/[A-Za-z]/", $fname)){
      	$errors['s'] = "Only characters are allowed in First Name";
      }else if(!preg_match("/[A-Za-z]/", $sname)){
      	$errors['s'] = "Only characters are allowed surname";
      }else if(!preg_match("/[0-9]/", $contact)){
      	$errors['s'] = "Only number are allowed";
      }else if(mysqli_num_rows($cc) >0){
      	$errors['s'] = "Phone number exist";
      }



      if (count($errors)==0) {
      	$query = "UPDATE signup SET firstname='$fname',surname='$sname',country='$country' ,contact='$contact' WHERE email='$emails'";

      	$res = mysqli_query($connect,$query);

      	if ($res) {
      		echo "<h3 class='text-center alert alert-success'>You Have Successfully updated your account</h3>";
      	}else{
      		echo "<h3 class='text-center alert alert-danger'>Failed To update please try again later</h3>";
      	}
      	 
      }else{
      	$e = $errors['s'];
      	echo "<h3 class='text-center alert alert-danger'>$e</h3>";
      }
      	


 ?>