 <?php
 session_start();
 include("conn.php");

include("function.php");



$f = $_POST['search'];
     $email = $_SESSION['chatbot'];
        
        $query = "SELECT * FROM signup WHERE firstname LIKE'%$f%' AND email !='$email'";

        $result = mysqli_query($connect,$query);

         if (mysqli_num_rows($result)==0) {
            echo  "<h3 class='text-center my-5'>No user found <br> For '".$f."'</h3>";
          
         }
        while ($row = mysqli_fetch_array($result)) {
               
               if ($row['status'] == 'Online') {
                   
                  $output =  chatonline($row['id'],$row['profile'],$row['firstname'],$row['role']);
               }else{
                   $output = chatoffline($row['id'],$row['profile'],$row['firstname'],$row['role']);
               }echo $output;
        }
    
        

       ?>