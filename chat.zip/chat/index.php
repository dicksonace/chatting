<?php 

include("header.php");
	
include("function.php");

if (!isset($_SESSION['chatbot'])) {
    echo "<script>window.location.href='login.php'</script>";
}


if (isset($_POST['update'])) {
	$file_extension = pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION);

   $allowed_image_extension = array(
        "png",
        "jpg",
        "jpeg"
    );

  $file = $_FILES['image'];


  $errrors = array();


  if (empty($_FILES['image'])) {
    $errrors['u'] = "Choose a profile";
  }else if (($_FILES["file-input"]["size"] > 2000000)) {
     $errrors['u'] = "Image size is too big";
  }else if (!in_array($file_extension, $allowed_image_extension)) {
    $errrors['u'] = "Only PNG and JPEG are allowed";
  }


  if (count($errrors)==0) {
    $email = $_SESSION['chatbot'];

       $img = $_FILES['image']['name'];
    $up = "UPDATE signup SET profile='$img' WHERE email='$email'";
    $re = mysqli_query($connect, "UPDATE signup SET  profile='$img' WHERE email='$email'");
     

    if ($re) {
      move_uploaded_file($_FILES['image']['tmp_name'] , "img/".$_FILES['image']['name']."");
     echo "<script>alert('Account')</script>";
    }else{
      echo "<script>alert('Invalid Account')</script>";
    }
  }
}


	 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 	  <link rel="stylesheet" type="text/css" href="ui/jquery-ui.css">
   <link rel="stylesheet" type="text/css" href="ui/jquery-ui.min.css">
    <link rel="stylesheet" type="text/css" href="ui/jquery-ui.structure.css">
    <link rel="stylesheet" type="text/css" href="ui/jquery-ui.structure.min.css">
    <link rel="stylesheet" type="text/css" href="ui/jquery-ui.theme.css">
    <link rel="stylesheet" type="text/css" href="ui/jquery-ui.them.min.css">

    <script type="text/javascript" src="ui/jquery-ui.js"></script>
     <script type="text/javascript" src="ui/jquery-ui.min.js"></script>
      <script type="text/javascript" src="ui/jquery-ui.js"></script>

 </head>
 <body >
 
<br><br><br><br><br>
  <div class="d-flex" id="wrapper" style="height: 70vh;">

   <?php 
     include("sidenav.php");

    ?>
  
    
    <!-- /#sidebar-wrapper -->

    

      <div class="container-fluid">
       <div class="col-md-12">
         <div class="row">
        
          
             <div class="col-md-9 " id="message" style="height: 76vh" id="chat">

              <?php
              
              if (isset($_GET['id'])) {
                $id = $_GET['id'];



                $s = mysqli_query($connect,"SELECT * FROM signup WHERE id='$id'");

                $row = mysqli_fetch_array($s);

                $_SESSION['c'] = $row['firstname'];
               
                $s = $row['email'];

                $_SESSION['id'] = $row['email'];

                $_SESSION['profile'] = $row['profile'];

                $res = $_SESSION['chatbot'];



                $up = "UPDATE chat SET status='read' WHERE reciever='$res' AND sender='$s'";

                $n = mysqli_query($connect,$up);

                if ($n) {
                   echo "";
                }else{
                   echo "";
                }










                echo '<nav class="bg-light my-0" style="height: 80px;position: fixed;width: 118vh">
   
    
     <div class="col-md-12">
      <div class="row">
        <div class="col-md-2">
   <img src=img/'.$row['profile'].' class="mx-5 my-3" style="width: 50px;border-radius: 50px;height:50px;">
        </div>
        <div class="col-md-2">
          <h5 class="text-center my-2 ">'.$row['firstname'].'<br><small class="text-success">'.$row['status'].'</small></h5>
          
        </div>
      </div>
    </div>
  </nav>

<br><br>
<div class="my-5" id="ajax_data" style="height: 48vh; overflow-x: hidden;overflow-y: scroll;">

 
</div>


   



<div class="bg-light shadow" style="height: 7vh;">
  <form method="post" class="my-2" id="form">
    <div class="col-md-12">
      <div class="row">
        <div class="col-md-10">
          <input type="text" id="dick" name="message" class="form-control" autocomplete="off" class="message" placeholder="Send Message to '.$row['firstname'].'">
        </div>
        <div class="col-md-2">
          <input type="submit" name="send" id="send" value="Send" class="btn btn-success">
        </div>
      </div>
    </div>
  </form>
</div>';
               
              }else{
                echo '<div id="welcome">
                  <h1 class="my-5 text-center">Feel the vibes of </h1>

                <center>
                  <img src="img/acce.jpg" class="card img-card" style="height: 350px; width: 300px;">
                </center>
               </div>
             ';
              }

             
              ?>

  





               
</div>












             <div class="col-md-3 shadow" style="border-left: 5px solid green; height: 81vh;overflow-x: hidden;overflow-y: scroll;">
             	<h6 class="text-success text-center my-4">Users Online</h6>
                 <hr>
             	<div class="" id="Online">
             		<div class="col-md-12">
             			
             			<?php 
                      $s = $_SESSION['chatbot'];
                     $online = "SELECT * FROM signup WHERE status='Online' AND email !='$s'";

                     $user = mysqli_query($connect,$online);

                         if (mysqli_num_rows($user) < 1) {
                         	echo ' <h6 class="text-center text-info">NO User is online</h6>';
                         }else{

                         while($rows = mysqli_fetch_array($user)){
                         users_online($rows['profile'],$rows['firstname'],$rows['role']);
                         }
                         
                         	
                         }


             			 ?>
             			
             		</div>
             	</div>
             </div>
         </d-iv>
       </div>
   </div>
</div>

 <?php
      $q = "SELECT * FROM signup WHERE email='".$_SESSION['chatbot']."'";

      $qq = mysqli_query($connect,$q);

      $row = mysqli_fetch_array($qq);
      $_SESSION['contact'] = $row['contact'];
    ?>

  <div id="account" title="My Account">
  	<center><img src="<?php echo "img/".$row['profile']."" ?>" class="card img-card img-thumbnail" style="border-radius: 20px;width: 100%;height: 250px;"></center>
  	<br><br>
   
    <div class="my-3">
   	<span ><b>Firstname:</b>  <?php echo "".$row['firstname'].""; ?></span>
  	<span class="mx-4"><b>Surname:</b>  <?php echo "".$row['surname'].""; ?></span>
    </div>
  	
  	<h6><b>Email:</b>  <?php echo "".$row['email'].""; ?></h6>
  	<div class="my-3">
   	<span><b>Gender:</b>  <?php echo "".$row['gender'].""; ?></span>
  	<span class="mx-4"><b>Country:</b>  <?php echo "".$row['country'].""; ?></span>
    </div>

    <div class="my-3">
   	<span><b>contact:</b>  <?php echo "".$row['contact'].""; ?></span>
  	<span class="mx-4"><b>role:</b>  <?php echo "".$row['role'].""; ?></span>
    </div>
  	
  	
  </div>


  <div id="profile" title="Profile">

<form method="post" enctype="multipart/form-data">
       				<?php 
                      echo '<img src="img/'.$row['profile'].'" class="img-responsive card img-card my-5 col-md-12" style="width:320px;height:200px;">';
                      if (isset($errrors['u'])) {
                        echo '
                         <h6 class="text text-center my-3 alert alert-danger">'.$errrors['u'].'</h6>
                        ';
                      }
       				 ?>
<input type="file" name="image" class="form-control">
<input type="submit" name="update" value="Update Profile" class="btn btn-success my-5 col-md-12" id="update">
       				
       			</form>
  </div>


  <div id="Notification" title="Notification">
     
  </div>


<div id="account_set" title="Account Settings">
    <form method="post" id="set">
      <div class="form-group">
        <label>Firstname</label>
        <input type="text" name="fname" class="form-control" id="fname" autocomplete="off">
      </div>
      <div class="form-group">
        <label>Surname</label>
        <input type="text" name="sname" class="form-control" autocomplete="off">
      </div>
      <div class="form-group">
        <label>Country</label>
        <input type="text" name="country" class="form-control" autocomplete="off">
      </div>
      <div class="form-group">
        <label>Contact</label>
        <input type="text" name="contact" class="form-control" autocomplete="off">
      </div>
      <div class="show"></div>
      <input type="submit" name="update" id="kk" class="btn btn-success" value="Update">
      
    </form> 
</div>



<script type="text/javascript">
	$(document).ready(function(){

	$("#account").hide();
     $("#account").dialog({
        autoOpen: false,
        width: 450,
        height: 'auto',
        position: [50, 150],
        create: function (event) {
            $(event.target).parent().css({ 'position': 'fixed', "left": 850, "top": 120});
          }
          });
        
        $(".account").click(function(event){
           event.preventDefault();
            $("#account").dialog("open");
              $("#profile").dialog("close");
        });


        	$("#profile").hide();
     $("#profile").dialog({
        autoOpen: false,
        width: 300,
        height: 'auto',
        position: [50, 150],
        create: function (event) {
            $(event.target).parent().css({ 'position': 'fixed', "left": 1000, "top": 120 });
          }
          });


        $(".profile").click(function(){
                $("#profile").dialog("open");
                  $("#account").dialog("close");
        });


             load();
            function load(){
        	$.ajax({
              url: "load_data.php",
              method:"POST",
              success:function(data){
                $("#img").html(data);
              }
        	});
        }

       chat_data();
      function chat_data(){


        $.ajax({
          url: "ajax_chat_data.php",
          method: "POST",
          success:function(data){
          $("#ajax_data").html(data);
          }
        });
      } 


      setInterval(chat_data,1000);



      $("#send").click(function(event){
           event.preventDefault();

        
           $.ajax({
            url:"ajax_send_data.php",
            method:"POST",
            data:$("#form").serialize(),
            success:function(data){
              $("#dick").val("");
              chat_data();
               
            }
           });
           
      });



      $("#search").keyup(function(event){
            event.preventDefault();
            var m = $("#search").val();
      
           $.ajax({
            url:"ajx_search.php",
            method:"POST",
            data:$("#me").serialize(),
            success:function(data){
              $("#done").html(data);
            }
          });
         
      });



      $("#Notification").dialog({
         autoOpen:false,
         width:500,
         height: 500,
        position: [50, 150],
        create: function (event) {
            $(event.target).parent().css({ 'position': 'fixed', "left": 400, "top": 120 });
          }
      });


      $("#noti").click(function(){
        $("#Notification").dialog("open");
        load_noti();
      })

      function load_noti(){

        $.ajax({
          url:"ajax_notification.php",
          method:"POST",
          success:function(data){
            $("#Notification").html(data);
          }
        });
      }



         $("#account_set").dialog({
         autoOpen:false,
         width:500,
         height: 500,
        position: [50, 150],
        create: function (event) {
            $(event.target).parent().css({ 'position': 'fixed', "left": 400, "top": 120 });
          }
      });
      $(".account_set").click(function(){
            $("#account_set").dialog("open");
          
      });


      $("#kk").click(function(event){
        event.preventDefault();
         //alert("done");

           $.ajax({
              url:"account_set.php",
              method:"POST",
              data:$("#set").serialize(),
              success:function(data){
              $(".show").html(data);
              json();
              }
            });
         
      });

       json();
      function json(){

        $.ajax({
          url: "ajax_json.php",
          method:"POST",
          dataType:"JSON",
          success:function(data){
            $("#fname").val(fname.data);
          }
        });
      }

	});
      
</script>

 </body>
 </html>


